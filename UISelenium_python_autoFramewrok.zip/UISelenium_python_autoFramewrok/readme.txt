﻿UItestframework项目目前具有以下功能：
1、对webdriver进行了第二次的简单封装，使用更加方便
2、具有打印日志的功能，打印在控制台和文件中
3、读取配置文件(.ini文件):
4、具有发邮件的功能:
5、生成测试报告：html测试报告的路径：
6、使用了PageObject模式来编写测试脚本
7、针对使用chrome浏览器，不打开浏览器，直接运行测试用例：
     用chrome-headless

整个项目的目录结构:
├─config 配置文件的目录
│  │  config.ini   存放配置文件
│  │  __init__.py
│    
│
├─driver   浏览器驱动
│  └─chromedriver.exe
│  
│          
├─data   测试数据
│  ├─formaldata # 正式环境测试数据
│  └─testdata  # 测试环境的数据
│          
│
├─utils  公共的文件库
│  ├─  Basepage.py
│  ├─ Browser_engine.py
│  ├─  log.py
│  ├─  get_email_parameter
│  ├─  __init__.py
│ 
│    
├─pageobjects 使用pageobject模式编写测试脚本，存放page的目录
│  ├─   baidu_homepage.py
│  ├─   baidu_new_home.py
│  ├─   __init__.py
│
│    
├─report 测试报告
│  ├─screenshots 截图目录
│  ├─testreports 日志目录
│  
│       
├─Logs 打印日志
│
│    
└─testsuite 存放测试用例
    ├─test_baidu_search.py
    ├─test_get_page_title.py
    ├─TestRunnerToEmail.py
    └─TestRunnerToReport.py
