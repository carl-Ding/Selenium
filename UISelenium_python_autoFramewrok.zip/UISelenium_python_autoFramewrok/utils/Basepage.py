# -*- coding:utf-8 -*-
# @Time   : 2019-10-17
# @Author : Dingjs

import time
import os
from UISelenium_python_autoFramewrok.utils.log import Logger
from selenium.common.exceptions import NoSuchElementException

# create a logger instance
logger = Logger(logger='BasePage').getlog()


class BasePage(object):
    """
    定义一个页面基类，让所有的页面都继承这个类，封装一些常用的页面操作方法
    """

    def __init__(self,driver):
        self.driver = driver

    #退出浏览器
    def quit_borwser(self):
        self.driver.quit()

    #打开url
    def open_url(self,url):
        self.driver.get(url)

    #浏览器前进操作
    def forward(self):
        self.driver.forward()
        logger.info("Click forward on current page.")

    #浏览器后退
    def back(self):
        self.driver.back()
        logger.info("Click back on current page.")

    #隐式等待
    def wait(self,seconds):
        self.driver.implicitly_wait(seconds)
        logger.info("wait for %d seconds." % seconds)

    #关闭当前窗口
    def close(self):
        try:
            self.driver.close()
            logger.info("Closing and quit the browser.")
        except NameError as e:
            logger.info("Faile to quit the browser with %s" %e)

    #保存图片
    def get_windows_img(self):

        file_path = os.path.dirname(os.getcwd()) + '/report/screenshots/'
        rq = time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))
        screen_name = os.path.join(file_path, '%s.png' % rq)  #可以使用os模块的join来写截图名字

        # cur_path = os.path.dirname(os.path.realpath(__file__))
        # image_path = os.path.join(os.path.dirname(cur_path), 'report')
        # screen_name = file_path + rq + '.jpg'  #文件名字的写法
        try:
            self.driver.get_screenshot_as_file(screen_name)
            logger.info("Had take screenshot and save to folder : /screenshots")

        except NameError as e:
            logger.error("Failed to take screenshot! %s" % e)
            self.get_windows_img()

    #元素定位
    def find_element(self,selector):
        """
        这里展示2中写法，
        ①是逐一定义每一个元素，
        ②传入元祖方式，传入的时候定义好定位的方式和元素

        :param selector:
        :return:
        """

    #第一种写法，使用的是切割字符串的方法
        # element = ''
        # if "=>" not in selector:
        #     return self.driver.find_element_by_id(selector)
        # selector_by = selector.split('=>')[0]
        # selector_value = selector.split('=>')[1]
        #
        # if selector_by == 'i' or selector_by == 'id':
        #     try:
        #         element = self.driver.find_element_by_id(selector_value)
        #         logger.info("Had  find the element \' %s  '\successful"
        #                     "by %s via value :%s " %(element.txt,selector_by,selector_value))
        #
        #     except NoSuchElementException as e:
        #         logger.error("NoSuchElementException %s " %e)
        #         #take screenshot
        #         self.get_windows_img()
        #
        # elif selector_by == 'n' or selector_by == 'name':
        #     element = self.driver.find_element_by_name(selector_value)
        #
        # elif selector_by == 'c' or selector_by == 'class_name':
        #     element = self.driver.find_element_by_class_name(selector_value)
        #
        # elif selector_by == 'l' or selector_by == 'link_text':
        #     element = self.driver.find_element_by_link_text(selector_value)
        #
        # elif selector_by == 'p' or selector_by == 'partial_link_text':
        #     element = self.driver.find_element_by_partial_link_text(selector_value)
        #
        # elif selector_by == 't' or selector_by == 'tag_name':
        #     element = self.driver.find_element_by_tag_name(selector_value)
        #
        # elif selector_by == 'x' or selector_by == 'xpath':
        #     try:
        #         element = self.driver.find_element_by_xpath(selector_value)
        #         logger.info("Had  find the element \' %s  '\successful"
        #                     "by %s via value :%s " %(element.txt,selector_by,selector_value))
        #
        #     except NoSuchElementException as e:
        #         logger.error("NoSuchElementException %s " %e)
        #         #take screenshot
        #         self.get_windows_img()
        #
        # elif selector_by == 's' or selector_by == 'selector_selector':
        #     element = self.driver.find_element_by_css_selector(selector_value)
        #
        # else:
        #     raise NameError("Please enter a valid type of targeting elements")
        #
        # return element

        # 第二种写法,如下：
        try:
            element = self.driver.find_element(selector)
            logger.info("The element looked up is %s " %(selector))
            return element

        except NoSuchElementException as e:
            logger.error("NoSuchElementException: %s" % e)
            self.get_windows_img()

    #输入
    def type(self,*selector,text):
        el = self.find_element(*selector)
        el.clear()
        try:
            el.send_keys(text)
            logger.info("Had type \ '%s' \ in input box" %text )

        except NameError as e:
            logger.error("Failed to type in input box with %s" % e)
            self.get_windows_img()

    #清除文本框
    def clear(self,selector):
        el = self.find_element(selector)
        try:
            el.clear()
            logger.info("Clear text in input box before typing.")

        except NameError as e:
            logger.error("Failed to clear in input box with %s" % e)
            self.get_windows_img()

    #点击元素
    def click(self,selector):
        el = self.find_element(selector)
        try:
            el.click()
            logger.info("The element \' %s \' was clicked." % el.text)

        except NameError as e:
            logger.error("Failed to click the element with %s" % e)
            self.get_windows_img()

    #点击元素
    def right_click(self,selector):
        el = self.find_element(selector)
        try:
            ActionChains(self.driver).context_click(el).perform()
            logger.info("The element \' %s \' was clicked." % el.text)
        except NameError as e:
            logger.error("Failed to right_click the element with %s" % e)
            self.get_windows_img()

    #双击
    def double_click(self,selector):
        el = self.find_element(selector)
        try:
            ActionChains(self.driver).double_click(el).perform()
        except Exception as e:
            logger.info("Failed to double_click the element with %s" % e)
            self.get_windows_img()
            raise

    #鼠标移到元素上
    def move_to_element(self,selector):
        try:
            el = self.find_element(selector)
            ActionChains(self.driver).move_to_element(el).perform()
        except Exception as e:
            logger.info("Failed to move_to_element the element with %s" % e)
            self.get_windows_img()
            raise

    # 拖拽
    def drag_and_drop(self, el_selector,ta_selector):
        try:
            el_drag = self.find_element(el_selector)
            taget_drop = self.find_element(ta_selector)
            ActionChains(self.driver).drag_and_drop(el_drag,taget_drop).perform()
        except Exception as e:
            logger.info("Failed to drag_and_drop the element with %s" % e)
            self.get_windows_img()
            raise

    # 刷新
    def refresh(self):
        self.driver.refresh()

    #submit
    def submit(self,selector):
        try:
            el = self.find_element(selector)
            el.submit()
        except Exception as e:
            logger.info("Failed to submit the element with %s" % e)
            self.get_windows_img()
            raise

    #获取元素的属性
    def get_attribute(self,selector,attribute):
        try:
            el = self.find_element(selector)
            return el.get_attribute(attribute)
        except Exception as e:
            logger.info("Failed to get_attribute  with %s" % e)
            self.get_windows_img()
            raise

    #获取元素的文本信息
    def get_text(self,selector):
        try:
            return self.find_element(selector).text
        except Exception as e:
            logger.info("Failed to get_text  with %s" % e)
            self.get_windows_img()

    #弹窗 alert——取消
    def dismiss_alert(self):
        self.driver.switch_to.alert.dismiss()

    #frame(切换到指定的帧视图)
    def switch_to_frame(self,selector):
        try:
            iframe_el = self.find_element(selector)
            self.driver.switch_to.frame(iframe_el)
        except Exception as e:
            logger.info("Failed to  switch_to_frame with %s" % e)
            self.get_windows_img()
            raise

    #退出当前帧视图
    def quit_frame(self):
        self.driver.switch_to.default_content()

    #打开并切换到新窗口
    def open_new_windwos(self,selector):
        try:
            original_windows = self.driver.current_window_handle
            self.find_element(selector).click() #点击打开新窗口
            all_handles = self.driver.window_handles
            for handle in all_handles:
                if handle != original_windows:
                    self.driver.switch_to.windows(handle) #切换到新窗口
        except Exception as e:
            logger.info("Failed to  switch_to_frame with %s" % e)
            self.get_windows_img()
            raise

    #js
    def js(self,script):
        '''
        driver.js("window.scrollTo(200,1000);")
        :param script:
        :return:
        '''
        try:
            self.driver.execute_script(script)
        except Exception as e:
            logger.info("Failed to js  with %s" % e)
            self.get_windows_img()
            raise


    # js,点击
    def js_click(self, selector):
        try:
            js_str = "$('{0}').click()".format(selector)
            self.driver.execute_script(js_str)
        except Exception as e:
            logger.info("Failed to js_click with %s" % e)
            self.get_windows_img()
            raise

    #判断元素是否存在
    def element_exist(self,selector):
        try:
            self.find_element(selector)
            return True
        except Exception as e:
            return False

    #输入并确认
    def type_enter(self,selector,text):
        try:
            ele = self.find_element(selector)
            ele.send_keys(text)
            time.sleep(1)
            ele.send_keys(Keys.ENTER)
        except Exception as e:
            logger.info("Failed to type_and_enter with %s" % e)
            self.get_windows_img()
            raise




    #获取网页标题
    def get_page_title(self):
        logger.info("Current page title is %s" % self.driver.title)
        return self.driver.title

    @staticmethod
    def sleep(seconds):
        time.sleep(seconds)
        logger.info("Sleep for %d seconds" % seconds)














